package com.example.practicanavclase.semaforo

interface BotonSemaforoListener {
    fun onClickButton()
}